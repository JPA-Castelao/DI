import sqlite3
import os

from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.charts.textlabels import Label
from reportlab.graphics.shapes import Drawing
from reportlab.lib.pagesizes import A4
from reportlab.platypus import Table
from reportlab.lib import colors
from reportlab.platypus import *
from reportlab.lib import *


def obter_produtos_mais_vendidos(self, limite=10):
    """Obter os produtos máis vendidos"""

    conn = sqlite3.connect(self)
    cursor = conn.cursor()

    cursor.execute("""
       SELECT 
        p.nome,
        SUM(If.cantidade) as total_vendido,
        SUM(If.cantidade*If.prezo_unitario*(1- If.desconto/100)) as facturacion
        FROM linhas_factura If
        JOIN produtos p on If.id_produto=p.id_produto
        GROUP BY p.id_produto,p.nome
        ORDER BY total_vendido DESC
        LIMIT ?             
     """, (limite,))

    resultados = cursor.fetchall()
    conn.close()
    return resultados


def grafica():
    d = Drawing(400, 400)

    produtos_lista = []
    cabecera = ['Posicion', 'Produto', 'Unidades vendidas', 'Facturacion']
    linha1 = [1, 'Memoria RAM DDR4 16GB', 81, '4324€']
    linha2 = [2, 'Memoria RAM DDR4 16GB', 81, '4324€']
    linha3 = [3, 'Memoria RAM DDR4 16GB', 81, '4324€']
    linha4 = [4, 'Memoria RAM DDR4 16GB', 81, '4324€']
    linha5 = [5, 'Memoria RAM DDR4 16GB', 81, '4324€']
    produtos_lista.append(cabecera)
    produtos_lista.append(linha1)
    produtos_lista.append(linha2)
    produtos_lista.append(linha3)
    produtos_lista.append(linha4)
    produtos_lista.append(linha5)

    datos = [(4324, 33648, 7429, 36269, 7632)]
    lendaDatos = ['Memoria RAM DDR4 16GB',
                  'Portátil HP Pavilion 15',
                  'Monitor Dell 24 polgadas',
                  'Torre de sobremesa Custom',
                  'Monitor LG 27 polgadas']

    graficoBarras = VerticalBarChart()
    graficoBarras.x = 0
    graficoBarras.y = 0
    graficoBarras.height = 100
    graficoBarras.width = 300
    graficoBarras.data = datos
    graficoBarras.valueAxis.valueMin = 0
    graficoBarras.valueAxis.valueMax = 100
    graficoBarras.valueAxis.valueStep = 10
    graficoBarras.categoryAxis.labels.boxAnchor = 'ne'
    graficoBarras.categoryAxis.labels.dx = 8
    graficoBarras.categoryAxis.labels.dy = -10
    graficoBarras.categoryAxis.labels.angle = 30
    graficoBarras.categoryAxis.categoryNames = lendaDatos
    graficoBarras.groupSpacing = 10

    graficoBarras.barSpacing = 3
    d.add(graficoBarras)
    return d


def adxuntar_datos():
    datos_columna = []
    colummnas_totales = []
    array_produtos = obter_produtos_mais_vendidos("/home/dam/DI/Reportlab/ExamenReportlab/bdTendaOrdeadoresBig.bd")
    for i in range(5):
        for sss in enumerate(array_produtos[i]):
            datos_columna.append(sss)
        colummnas_totales.append(datos_columna)

        print(colummnas_totales[i])
    return colummnas_totales


def crear_taboa():
    produtos_lista = []
    cabecera = ['Posicion', 'Produto', 'Unidades vendidas', 'Facturacion']
    linha1 = [1, 'Memoria RAM DDR4 16GB', 81, '4324€']
    linha2 = [2, 'Memoria RAM DDR4 16GB', 81, '4324€']
    linha3 = [3, 'Memoria RAM DDR4 16GB', 81, '4324€']
    linha4 = [4, 'Memoria RAM DDR4 16GB', 81, '4324€']
    linha5 = [5, 'Memoria RAM DDR4 16GB', 81, '4324€']
    produtos_lista.append(cabecera)
    produtos_lista.append(linha1)
    produtos_lista.append(linha2)
    produtos_lista.append(linha3)
    produtos_lista.append(linha4)
    produtos_lista.append(linha5)

    # taboa = Table(adxuntar_datos())#
    taboa = Table(produtos_lista)
    taboa.setStyle(([
        ('BACKGROUND', (0, 0), (4, 0), colors.red),
        ('TEXTCOLOR', (0, 0), (4, 0), colors.white),
        ("BOX", (0, 0), (-1, -1), 1, colors.black),
        ('INNERGRID', (0, 1), (4, -1), 1, colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'), ]))

    guion = []

    guion.append(taboa)
    guion.append(grafica())
    doc = SimpleDocTemplate("TaboaProdutos.pdf", pagesize=A4)
    doc.build(guion)


if __name__ == '__main__':
    crear_taboa()
    print(obter_produtos_mais_vendidos("/home/dam/DI/Reportlab/ExamenReportlab/bdTendaOrdeadoresBig.bd"))
